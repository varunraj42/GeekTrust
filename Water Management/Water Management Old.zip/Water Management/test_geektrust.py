import unittest
from geektrust import main

class TestGeekTrust(unittest.TestCase):

    def test_water_bill(self):
        self.assertTrue()
