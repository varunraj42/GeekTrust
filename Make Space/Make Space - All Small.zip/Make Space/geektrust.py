from datetime import datetime
import datetime as dt

class Room:
    MIN_ATTENDEES = 2
    MAX_ATTENDEES = 20
    MAINT_TIMINGS = ["09:00", "13:15", "18:45"]
    DATE_FORMAT = "%H:%M"
    START_END_INTERVAL = 15


    def __init__(self, roomtype, maxcapacity):
        self.availtimings =  self.getalltimeslots()
        self.maxcapacity = maxcapacity
        self.roomtype = roomtype


    def getalltimeslots(self):
        availtimings = []

        for hour in range(0, 24):
            for min in range(0, 60, 15):
                datetimeobj = datetime.strptime(f"{hour}:{min}", Room.DATE_FORMAT)
                if datetimeobj.strftime(Room.DATE_FORMAT) not in Room.MAINT_TIMINGS:
                    availtimings.append(datetimeobj)

        return availtimings


    def validatemeetingtimings(self, startat, endat):
        try:
            if all([(startat < endat), (startat.minute%15 ==0 and endat.minute%15 ==0) ]):
                return True
        except ValueError as ve:
            pass

        return False


    def getreqtimeslots(self, startat, endat):
        reqtimeslots = []

        timeslot = startat
        while timeslot < endat:
            reqtimeslots.append(timeslot)
            timeslot += dt.timedelta(minutes=15)

        return reqtimeslots


    def isavailable(self, capacityreq, startat, endat, blockingslot=True):
        startat = datetime.strptime(startat, "%H:%M")
        endat = datetime.strptime(endat, "%H:%M")

        if self.validatemeetingtimings(startat, endat):
            reqtimeslots = self.getreqtimeslots(startat, endat)

            for slot in reqtimeslots:
                if slot not in self.availtimings or capacityreq > self.maxcapacity:
                    return False
                elif blockingslot:
                    self.availtimings.remove(slot)
        else:
            return "INCORRECT INPUT"

        return True


def readinput(filename):
    with open(filename, 'r') as input:
        data = input.read()

    return data

def listvacantrooms(startat, endat, roomtypes):
    vacantrooms = []
    for room in roomtypes:
        isavailable = room.isavailable(0, startat, endat, blockingslot=False)

        if isavailable == "INCORRECT INPUT":
            return "INCORRECT_INPUT"

        if isavailable:
            vacantrooms.append(room.roomtype)

    if len(vacantrooms) == 0:
        return f"NO_VACANT_ROOM"

    return f"{' '.join(vacantrooms)}"


def bookvacantrooms(startat, endat, capacityreq, roomtypes):
    booked = False
    for room in roomtypes:
        isavailable = room.isavailable(capacityreq, startat, endat)

        if capacityreq < 2 or isavailable == "INCORRECT INPUT":
            return "INCORRECT_INPUT"

        if isavailable:
            booked = True
            return f"{room.roomtype}"

    if not booked:
        return "NO_VACANT_ROOM"



def run(filename):
    instructions = readinput(filename)
    instructions = instructions.split('\n')

    output = []

    cave = Room("C-Cave", 3)
    tower = Room("D-Tower", 7)
    mansion = Room("G-Mansion", 20)
    for ins in instructions:
        if 'VACANCY' in ins and ins !='':
            command, startat, endat = ins.split(' ')
            output.append(listvacantrooms(startat, endat, [cave, tower, mansion]))

        elif 'BOOK' in ins and ins !='':
            command, startat, endat, capacityreq = ins.split(' ')
            capacityreq = int(capacityreq)
            output.append(bookvacantrooms(startat, endat, capacityreq, [cave, tower, mansion]))

    return '\n'.join(output)


if __name__ == '__main__':
    import sys
    filename = sys.argv[1]
    print(run(filename))
